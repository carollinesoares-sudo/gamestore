package br.senai.estoque.gerenciamento_estoque.service;

import java.util.List;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import br.senai.estoque.gerenciamento_estoque.model.Material;
import br.senai.estoque.gerenciamento_estoque.repository.MaterialRepository;

@Service
public class MaterialService {

    private final MaterialRepository materialRepository;

    public MaterialService(MaterialRepository materialRepository) {
        this.materialRepository = materialRepository;
    }

    public List<Material> listarTodos() {
        return materialRepository.findAllByOrderByNomeAsc();
    }

    public Material buscarPorId(Long id) {
        return materialRepository.findById(id)
                .orElseThrow(() -> new RegraNegocioException("Material não encontrado."));
    }

    public Material salvar(Material material) {
        normalizarCampos(material);
        return materialRepository.save(material);
    }

    public void excluir(Long id) {
        Material material = buscarPorId(id);
        try {
            materialRepository.delete(material);
        } catch (DataIntegrityViolationException ex) {
            throw new RegraNegocioException("Nao foi possivel excluir o material porque ele possui movimentacoes registradas.");
        }
    }

    public void atualizarQuantidade(Material material, int novaQuantidade) {
        material.setQuantidade(novaQuantidade);
        materialRepository.save(material);
    }

    private void normalizarCampos(Material material) {
        material.setNome(material.getNome().trim());
        material.setUnidadeMedida(material.getUnidadeMedida().trim());
        if (material.getDescricao() != null) {
            material.setDescricao(material.getDescricao().trim());
        }
        if (material.getQuantidade() == null) {
            material.setQuantidade(0);
        }
    }
}
