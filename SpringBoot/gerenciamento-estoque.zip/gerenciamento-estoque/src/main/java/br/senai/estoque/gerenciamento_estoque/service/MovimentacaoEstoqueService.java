package br.senai.estoque.gerenciamento_estoque.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.senai.estoque.gerenciamento_estoque.model.Funcionario;
import br.senai.estoque.gerenciamento_estoque.model.Material;
import br.senai.estoque.gerenciamento_estoque.model.MovimentacaoEstoque;
import br.senai.estoque.gerenciamento_estoque.model.TipoMovimentacao;
import br.senai.estoque.gerenciamento_estoque.repository.MovimentacaoEstoqueRepository;

@Service
public class MovimentacaoEstoqueService {

    private final MovimentacaoEstoqueRepository movimentacaoEstoqueRepository;
    private final MaterialService materialService;

    public MovimentacaoEstoqueService(MovimentacaoEstoqueRepository movimentacaoEstoqueRepository,
            MaterialService materialService) {
        this.movimentacaoEstoqueRepository = movimentacaoEstoqueRepository;
        this.materialService = materialService;
    }

    public List<MovimentacaoEstoque> listarTodas() {
        return movimentacaoEstoqueRepository.findAllByOrderByDataMovimentacaoDesc();
    }

    @Transactional
    public void registrar(MovimentacaoEstoque movimentacaoEstoque, Funcionario funcionarioResponsavel) {
        Material material = materialService.buscarPorId(movimentacaoEstoque.getMaterial().getId());
        int saldoAtual = material.getQuantidade();
        int quantidade = movimentacaoEstoque.getQuantidade();

        if (movimentacaoEstoque.getTipoMovimentacao() == TipoMovimentacao.SAIDA && quantidade > saldoAtual) {
            throw new RegraNegocioException("A saída não pode ser maior que o saldo disponível.");
        }

        int novoSaldo = movimentacaoEstoque.getTipoMovimentacao() == TipoMovimentacao.ENTRADA
                ? saldoAtual + quantidade
                : saldoAtual - quantidade;

        materialService.atualizarQuantidade(material, novoSaldo);
        movimentacaoEstoque.setMaterial(material);
        movimentacaoEstoque.setFuncionarioResponsavel(funcionarioResponsavel);
        if (movimentacaoEstoque.getObservacao() != null) {
            movimentacaoEstoque.setObservacao(movimentacaoEstoque.getObservacao().trim());
        }
        movimentacaoEstoqueRepository.save(movimentacaoEstoque);
    }
}
