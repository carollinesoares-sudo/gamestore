MERGE INTO funcionarios_autenticados (nif, nome, ativo)
KEY(nif)
VALUES ('12345', 'Carol', TRUE);

MERGE INTO funcionarios_autenticados (nif, nome, ativo)
KEY(nif)
VALUES ('54321', 'Joao Silva', TRUE);
