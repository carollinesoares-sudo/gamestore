package br.senai.estoque.gerenciamento_estoque.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.senai.estoque.gerenciamento_estoque.model.AtivoPatrimonial;
import br.senai.estoque.gerenciamento_estoque.service.AtivoPatrimonialService;
import br.senai.estoque.gerenciamento_estoque.service.RegraNegocioException;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

@Controller
@RequestMapping("/app/ativos")
public class AtivoPatrimonialController {

    private final AtivoPatrimonialService ativoPatrimonialService;

    public AtivoPatrimonialController(AtivoPatrimonialService ativoPatrimonialService) {
        this.ativoPatrimonialService = ativoPatrimonialService;
    }

    @GetMapping
    public String listar(Model model, HttpSession session) {
        String redirect = ControllerUtils.redirecionarSeNaoLogado(session);
        if (redirect != null) {
            return redirect;
        }

        ControllerUtils.adicionarDadosSessao(model, session);
        model.addAttribute("ativos", ativoPatrimonialService.listarTodos());
        return "ativos/lista";
    }

    @GetMapping("/novo")
    public String novo(Model model, HttpSession session) {
        return abrirFormulario(new AtivoPatrimonial(), model, session, "Novo ativo patrimonial");
    }

    @GetMapping("/{id}/editar")
    public String editar(@PathVariable Long id, Model model, HttpSession session) {
        AtivoPatrimonial ativo = ativoPatrimonialService.buscarPorId(id);
        return abrirFormulario(ativo, model, session, "Editar ativo patrimonial");
    }

    @PostMapping("/salvar")
    public String salvar(@Valid @ModelAttribute("ativo") AtivoPatrimonial ativoPatrimonial,
            BindingResult bindingResult,
            Model model,
            HttpSession session,
            RedirectAttributes redirectAttributes) {

        String redirect = ControllerUtils.redirecionarSeNaoLogado(session);
        if (redirect != null) {
            return redirect;
        }

        if (bindingResult.hasErrors()) {
            return abrirFormulario(ativoPatrimonial, model, session,
                    ativoPatrimonial.getId() == null ? "Novo ativo patrimonial" : "Editar ativo patrimonial");
        }

        try {
            ativoPatrimonialService.salvar(ativoPatrimonial);
            redirectAttributes.addFlashAttribute("sucesso", "Ativo patrimonial salvo com sucesso.");
            return "redirect:/app/ativos";
        } catch (RegraNegocioException ex) {
            model.addAttribute("erro", ex.getMessage());
            return abrirFormulario(ativoPatrimonial, model, session,
                    ativoPatrimonial.getId() == null ? "Novo ativo patrimonial" : "Editar ativo patrimonial");
        }
    }

    @PostMapping("/{id}/excluir")
    public String excluir(@PathVariable Long id, RedirectAttributes redirectAttributes, HttpSession session) {
        String redirect = ControllerUtils.redirecionarSeNaoLogado(session);
        if (redirect != null) {
            return redirect;
        }

        try {
            ativoPatrimonialService.excluir(id);
            redirectAttributes.addFlashAttribute("sucesso", "Ativo patrimonial excluido com sucesso.");
        } catch (RegraNegocioException ex) {
            redirectAttributes.addFlashAttribute("erro", ex.getMessage());
        }
        return "redirect:/app/ativos";
    }

    private String abrirFormulario(AtivoPatrimonial ativo, Model model, HttpSession session, String titulo) {
        String redirect = ControllerUtils.redirecionarSeNaoLogado(session);
        if (redirect != null) {
            return redirect;
        }

        ControllerUtils.adicionarDadosSessao(model, session);
        model.addAttribute("ativo", ativo);
        model.addAttribute("tituloPagina", titulo);
        return "ativos/formulario";
    }
}
