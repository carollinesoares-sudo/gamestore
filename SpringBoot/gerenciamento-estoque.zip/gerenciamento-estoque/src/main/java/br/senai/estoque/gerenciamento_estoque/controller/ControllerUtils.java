package br.senai.estoque.gerenciamento_estoque.controller;

import org.springframework.ui.Model;

import jakarta.servlet.http.HttpSession;

public final class ControllerUtils {

    private ControllerUtils() {
    }

    public static boolean usuarioLogado(HttpSession session) {
        Object usuarioLogado = session.getAttribute("usuarioLogado");
        return usuarioLogado instanceof Boolean && (Boolean) usuarioLogado;
    }

    public static String redirecionarSeNaoLogado(HttpSession session) {
        return usuarioLogado(session) ? null : "redirect:/login";
    }

    public static void adicionarDadosSessao(Model model, HttpSession session) {
        model.addAttribute("usuarioLogado", usuarioLogado(session));
        model.addAttribute("nomeUsuario", session.getAttribute("nomeUsuario"));
        model.addAttribute("nifUsuario", session.getAttribute("nif"));
    }
}
