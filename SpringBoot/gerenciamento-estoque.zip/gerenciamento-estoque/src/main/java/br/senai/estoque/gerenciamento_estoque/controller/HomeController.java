package br.senai.estoque.gerenciamento_estoque.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import jakarta.servlet.http.HttpSession;

@Controller
public class HomeController {

    @GetMapping("/")
    public String index(Model model, HttpSession session) {
        ControllerUtils.adicionarDadosSessao(model, session);
        return "index";
    }
}
