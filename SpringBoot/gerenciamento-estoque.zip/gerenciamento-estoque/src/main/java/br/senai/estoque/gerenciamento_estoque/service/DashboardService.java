package br.senai.estoque.gerenciamento_estoque.service;

import org.springframework.stereotype.Service;

import br.senai.estoque.gerenciamento_estoque.repository.AtivoPatrimonialRepository;
import br.senai.estoque.gerenciamento_estoque.repository.CategoriaMaterialRepository;
import br.senai.estoque.gerenciamento_estoque.repository.MaterialRepository;
import br.senai.estoque.gerenciamento_estoque.repository.MovimentacaoEstoqueRepository;

@Service
public class DashboardService {

    private final CategoriaMaterialRepository categoriaMaterialRepository;
    private final MaterialRepository materialRepository;
    private final MovimentacaoEstoqueRepository movimentacaoEstoqueRepository;
    private final AtivoPatrimonialRepository ativoPatrimonialRepository;

    public DashboardService(CategoriaMaterialRepository categoriaMaterialRepository,
            MaterialRepository materialRepository,
            MovimentacaoEstoqueRepository movimentacaoEstoqueRepository,
            AtivoPatrimonialRepository ativoPatrimonialRepository) {
        this.categoriaMaterialRepository = categoriaMaterialRepository;
        this.materialRepository = materialRepository;
        this.movimentacaoEstoqueRepository = movimentacaoEstoqueRepository;
        this.ativoPatrimonialRepository = ativoPatrimonialRepository;
    }

    public long totalCategorias() {
        return categoriaMaterialRepository.count();
    }

    public long totalMateriais() {
        return materialRepository.count();
    }

    public long totalMovimentacoes() {
        return movimentacaoEstoqueRepository.count();
    }

    public long totalAtivos() {
        return ativoPatrimonialRepository.count();
    }
}
