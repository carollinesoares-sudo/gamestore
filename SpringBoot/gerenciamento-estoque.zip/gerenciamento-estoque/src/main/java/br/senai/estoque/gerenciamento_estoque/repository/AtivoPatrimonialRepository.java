package br.senai.estoque.gerenciamento_estoque.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import br.senai.estoque.gerenciamento_estoque.model.AtivoPatrimonial;

public interface AtivoPatrimonialRepository extends JpaRepository<AtivoPatrimonial, Long> {

    boolean existsByNumeroPatrimonio(String numeroPatrimonio);

    boolean existsByNumeroPatrimonioAndIdNot(String numeroPatrimonio, Long id);

    List<AtivoPatrimonial> findAllByOrderByNomeAsc();
}
