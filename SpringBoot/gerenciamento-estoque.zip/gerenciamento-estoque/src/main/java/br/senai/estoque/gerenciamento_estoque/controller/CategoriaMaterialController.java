package br.senai.estoque.gerenciamento_estoque.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.senai.estoque.gerenciamento_estoque.model.CategoriaMaterial;
import br.senai.estoque.gerenciamento_estoque.service.CategoriaMaterialService;
import br.senai.estoque.gerenciamento_estoque.service.RegraNegocioException;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

@Controller
@RequestMapping("/app/categorias")
public class CategoriaMaterialController {

    private final CategoriaMaterialService categoriaMaterialService;

    public CategoriaMaterialController(CategoriaMaterialService categoriaMaterialService) {
        this.categoriaMaterialService = categoriaMaterialService;
    }

    @GetMapping
    public String listar(Model model, HttpSession session) {
        String redirect = ControllerUtils.redirecionarSeNaoLogado(session);
        if (redirect != null) {
            return redirect;
        }

        ControllerUtils.adicionarDadosSessao(model, session);
        model.addAttribute("categorias", categoriaMaterialService.listarTodas());
        return "categorias/lista";
    }

    @GetMapping("/nova")
    public String nova(Model model, HttpSession session) {
        return abrirFormulario(new CategoriaMaterial(), model, session, "Nova categoria");
    }

    @GetMapping("/{id}/editar")
    public String editar(@PathVariable Long id, Model model, HttpSession session) {
        CategoriaMaterial categoria = categoriaMaterialService.buscarPorId(id);
        return abrirFormulario(categoria, model, session, "Editar categoria");
    }

    @PostMapping("/salvar")
    public String salvar(@Valid @ModelAttribute("categoria") CategoriaMaterial categoria,
            BindingResult bindingResult,
            Model model,
            HttpSession session,
            RedirectAttributes redirectAttributes) {

        String redirect = ControllerUtils.redirecionarSeNaoLogado(session);
        if (redirect != null) {
            return redirect;
        }

        if (bindingResult.hasErrors()) {
            return abrirFormulario(categoria, model, session,
                    categoria.getId() == null ? "Nova categoria" : "Editar categoria");
        }

        try {
            categoriaMaterialService.salvar(categoria);
            redirectAttributes.addFlashAttribute("sucesso", "Categoria salva com sucesso.");
            return "redirect:/app/categorias";
        } catch (RegraNegocioException ex) {
            model.addAttribute("erro", ex.getMessage());
            return abrirFormulario(categoria, model, session,
                    categoria.getId() == null ? "Nova categoria" : "Editar categoria");
        }
    }

    @PostMapping("/{id}/excluir")
    public String excluir(@PathVariable Long id, RedirectAttributes redirectAttributes, HttpSession session) {
        String redirect = ControllerUtils.redirecionarSeNaoLogado(session);
        if (redirect != null) {
            return redirect;
        }

        try {
            categoriaMaterialService.excluir(id);
            redirectAttributes.addFlashAttribute("sucesso", "Categoria excluida com sucesso.");
        } catch (RegraNegocioException ex) {
            redirectAttributes.addFlashAttribute("erro", ex.getMessage());
        }
        return "redirect:/app/categorias";
    }

    private String abrirFormulario(CategoriaMaterial categoria, Model model, HttpSession session, String titulo) {
        String redirect = ControllerUtils.redirecionarSeNaoLogado(session);
        if (redirect != null) {
            return redirect;
        }

        ControllerUtils.adicionarDadosSessao(model, session);
        model.addAttribute("categoria", categoria);
        model.addAttribute("tituloPagina", titulo);
        return "categorias/formulario";
    }
}
