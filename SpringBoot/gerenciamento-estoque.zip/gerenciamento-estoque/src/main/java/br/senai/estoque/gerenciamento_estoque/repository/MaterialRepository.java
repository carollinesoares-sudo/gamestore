package br.senai.estoque.gerenciamento_estoque.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import br.senai.estoque.gerenciamento_estoque.model.Material;

public interface MaterialRepository extends JpaRepository<Material, Long> {

    List<Material> findAllByOrderByNomeAsc();
}
