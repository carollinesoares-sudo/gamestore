package br.senai.estoque.gerenciamento_estoque.service;

import java.util.List;

import org.springframework.stereotype.Service;

import br.senai.estoque.gerenciamento_estoque.model.AtivoPatrimonial;
import br.senai.estoque.gerenciamento_estoque.repository.AtivoPatrimonialRepository;

@Service
public class AtivoPatrimonialService {

    private final AtivoPatrimonialRepository ativoPatrimonialRepository;

    public AtivoPatrimonialService(AtivoPatrimonialRepository ativoPatrimonialRepository) {
        this.ativoPatrimonialRepository = ativoPatrimonialRepository;
    }

    public List<AtivoPatrimonial> listarTodos() {
        return ativoPatrimonialRepository.findAllByOrderByNomeAsc();
    }

    public AtivoPatrimonial buscarPorId(Long id) {
        return ativoPatrimonialRepository.findById(id)
                .orElseThrow(() -> new RegraNegocioException("Ativo patrimonial não encontrado."));
    }

    public AtivoPatrimonial salvar(AtivoPatrimonial ativoPatrimonial) {
        normalizar(ativoPatrimonial);
        validarNumeroPatrimonio(ativoPatrimonial);
        return ativoPatrimonialRepository.save(ativoPatrimonial);
    }

    public void excluir(Long id) {
        AtivoPatrimonial ativo = buscarPorId(id);
        ativoPatrimonialRepository.delete(ativo);
    }

    private void normalizar(AtivoPatrimonial ativoPatrimonial) {
        ativoPatrimonial.setNome(ativoPatrimonial.getNome().trim());
        ativoPatrimonial.setNumeroPatrimonio(ativoPatrimonial.getNumeroPatrimonio().trim());
        ativoPatrimonial.setLocalizacao(ativoPatrimonial.getLocalizacao().trim());
        ativoPatrimonial.setEstadoConservacao(ativoPatrimonial.getEstadoConservacao().trim());
        if (ativoPatrimonial.getDescricao() != null) {
            ativoPatrimonial.setDescricao(ativoPatrimonial.getDescricao().trim());
        }
        if (ativoPatrimonial.getResponsavel() != null) {
            ativoPatrimonial.setResponsavel(ativoPatrimonial.getResponsavel().trim());
        }
        if (ativoPatrimonial.getObservacao() != null) {
            ativoPatrimonial.setObservacao(ativoPatrimonial.getObservacao().trim());
        }
    }

    private void validarNumeroPatrimonio(AtivoPatrimonial ativoPatrimonial) {
        boolean existe = ativoPatrimonial.getId() == null
                ? ativoPatrimonialRepository.existsByNumeroPatrimonio(ativoPatrimonial.getNumeroPatrimonio())
                : ativoPatrimonialRepository.existsByNumeroPatrimonioAndIdNot(
                        ativoPatrimonial.getNumeroPatrimonio(),
                        ativoPatrimonial.getId());

        if (existe) {
            throw new RegraNegocioException("Já existe um ativo com esse número patrimonial.");
        }
    }
}
