package br.senai.estoque.gerenciamento_estoque.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.senai.estoque.gerenciamento_estoque.model.Funcionario;
import br.senai.estoque.gerenciamento_estoque.model.Material;
import br.senai.estoque.gerenciamento_estoque.model.MovimentacaoEstoque;
import br.senai.estoque.gerenciamento_estoque.model.TipoMovimentacao;
import br.senai.estoque.gerenciamento_estoque.service.AuthService;
import br.senai.estoque.gerenciamento_estoque.service.MaterialService;
import br.senai.estoque.gerenciamento_estoque.service.MovimentacaoEstoqueService;
import br.senai.estoque.gerenciamento_estoque.service.RegraNegocioException;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

@Controller
@RequestMapping("/app/movimentacoes")
public class MovimentacaoEstoqueController {

    private final MovimentacaoEstoqueService movimentacaoEstoqueService;
    private final MaterialService materialService;
    private final AuthService authService;

    public MovimentacaoEstoqueController(MovimentacaoEstoqueService movimentacaoEstoqueService,
            MaterialService materialService,
            AuthService authService) {
        this.movimentacaoEstoqueService = movimentacaoEstoqueService;
        this.materialService = materialService;
        this.authService = authService;
    }

    @GetMapping
    public String listar(Model model, HttpSession session) {
        String redirect = ControllerUtils.redirecionarSeNaoLogado(session);
        if (redirect != null) {
            return redirect;
        }

        ControllerUtils.adicionarDadosSessao(model, session);
        model.addAttribute("movimentacoes", movimentacaoEstoqueService.listarTodas());
        MovimentacaoEstoque movimentacao = new MovimentacaoEstoque();
        movimentacao.setMaterial(new Material());
        model.addAttribute("movimentacao", movimentacao);
        model.addAttribute("tiposMovimentacao", TipoMovimentacao.values());
        model.addAttribute("materiais", materialService.listarTodos());
        return "movimentacoes/lista";
    }

    @PostMapping("/registrar")
    public String registrar(@Valid @ModelAttribute("movimentacao") MovimentacaoEstoque movimentacao,
            BindingResult bindingResult,
            Model model,
            HttpSession session,
            RedirectAttributes redirectAttributes) {

        String redirect = ControllerUtils.redirecionarSeNaoLogado(session);
        if (redirect != null) {
            return redirect;
        }

        if (bindingResult.hasErrors()) {
            if (movimentacao.getMaterial() == null) {
                movimentacao.setMaterial(new Material());
            }
            ControllerUtils.adicionarDadosSessao(model, session);
            model.addAttribute("movimentacoes", movimentacaoEstoqueService.listarTodas());
            model.addAttribute("tiposMovimentacao", TipoMovimentacao.values());
            model.addAttribute("materiais", materialService.listarTodos());
            model.addAttribute("erro", "Revise os dados da movimentacao.");
            return "movimentacoes/lista";
        }

        try {
            Funcionario funcionario = authService.buscarPorNif((String) session.getAttribute("nif"));
            movimentacaoEstoqueService.registrar(movimentacao, funcionario);
            redirectAttributes.addFlashAttribute("sucesso", "Movimentacao registrada com sucesso.");
        } catch (RegraNegocioException ex) {
            redirectAttributes.addFlashAttribute("erro", ex.getMessage());
        }

        return "redirect:/app/movimentacoes";
    }
}
