package br.senai.estoque.gerenciamento_estoque.service;

public class RegraNegocioException extends RuntimeException {

    public RegraNegocioException(String message) {
        super(message);
    }
}
