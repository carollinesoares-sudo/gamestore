package br.senai.estoque.gerenciamento_estoque.model;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "ativos_patrimoniais")
public class AtivoPatrimonial {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Informe o nome do ativo.")
    @Size(max = 100, message = "O nome deve ter no máximo 100 caracteres.")
    @Column(nullable = false, length = 100)
    private String nome;

    @Size(max = 255, message = "A descrição deve ter no máximo 255 caracteres.")
    @Column(length = 255)
    private String descricao;

    @NotBlank(message = "Informe o número patrimonial.")
    @Size(max = 40, message = "O número patrimonial deve ter no máximo 40 caracteres.")
    @Column(nullable = false, unique = true, length = 40)
    private String numeroPatrimonio;

    @NotBlank(message = "Informe a localização.")
    @Size(max = 120, message = "A localização deve ter no máximo 120 caracteres.")
    @Column(nullable = false, length = 120)
    private String localizacao;

    @NotBlank(message = "Informe o estado de conservação.")
    @Size(max = 60, message = "O estado deve ter no máximo 60 caracteres.")
    @Column(nullable = false, length = 60)
    private String estadoConservacao;

    @Column(nullable = false)
    private LocalDate dataCadastro;

    @Size(max = 120, message = "O responsável deve ter no máximo 120 caracteres.")
    @Column(length = 120)
    private String responsavel;

    @Size(max = 255, message = "A observação deve ter no máximo 255 caracteres.")
    @Column(length = 255)
    private String observacao;

    @PrePersist
    public void prePersist() {
        if (dataCadastro == null) {
            dataCadastro = LocalDate.now();
        }
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getNumeroPatrimonio() {
        return numeroPatrimonio;
    }

    public void setNumeroPatrimonio(String numeroPatrimonio) {
        this.numeroPatrimonio = numeroPatrimonio;
    }

    public String getLocalizacao() {
        return localizacao;
    }

    public void setLocalizacao(String localizacao) {
        this.localizacao = localizacao;
    }

    public String getEstadoConservacao() {
        return estadoConservacao;
    }

    public void setEstadoConservacao(String estadoConservacao) {
        this.estadoConservacao = estadoConservacao;
    }

    public LocalDate getDataCadastro() {
        return dataCadastro;
    }

    public void setDataCadastro(LocalDate dataCadastro) {
        this.dataCadastro = dataCadastro;
    }

    public String getResponsavel() {
        return responsavel;
    }

    public void setResponsavel(String responsavel) {
        this.responsavel = responsavel;
    }

    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }
}
