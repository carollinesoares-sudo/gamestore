package br.senai.estoque.gerenciamento_estoque.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import br.senai.estoque.gerenciamento_estoque.service.DashboardService;
import jakarta.servlet.http.HttpSession;

@Controller
public class AppController {

    private final DashboardService dashboardService;

    public AppController(DashboardService dashboardService) {
        this.dashboardService = dashboardService;
    }

    @GetMapping("/app")
    public String app(HttpSession session, Model model) {
        String redirect = ControllerUtils.redirecionarSeNaoLogado(session);
        if (redirect != null) {
            return redirect;
        }

        ControllerUtils.adicionarDadosSessao(model, session);
        model.addAttribute("totalCategorias", dashboardService.totalCategorias());
        model.addAttribute("totalMateriais", dashboardService.totalMateriais());
        model.addAttribute("totalMovimentacoes", dashboardService.totalMovimentacoes());
        model.addAttribute("totalAtivos", dashboardService.totalAtivos());
        return "app/index";
    }
}
