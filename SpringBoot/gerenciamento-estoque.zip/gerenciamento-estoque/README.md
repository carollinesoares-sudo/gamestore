# Sistema de Gerenciamento de Estoque e Patrimonio

Projeto academico em Spring Boot para controle de materiais de estoque e ativos patrimoniais de uma unidade escolar do SENAI-SP.

## Tecnologias

- Java 17
- Maven
- Spring Boot
- Spring Web
- Spring Data JPA
- Thymeleaf
- H2 Database
- HTML/CSS

## Como executar

1. Tenha Java 17 instalado.
2. No diretorio do projeto, execute:

```bash
./mvnw spring-boot:run
```

No Windows PowerShell:

```powershell
.\mvnw.cmd spring-boot:run
```

3. Acesse `http://localhost:8080`.
4. Console H2: `http://localhost:8080/h2-console`
5. JDBC URL do H2: `jdbc:h2:file:./data/estoque`

## Fluxo inicial de demonstracao

- O cadastro so funciona para NIFs previamente autorizados.
- Dados iniciais autorizados:
- NIF `12345` com nome `Carol`
- NIF `54321` com nome `Joao Silva`
- Primeiro faca o cadastro com um desses NIFs e depois realize o login.

## Requisitos funcionais atendidos

- RF01. Login com NIF e senha.
- RF02. Cadastro de funcionario apenas se estiver autorizado previamente.
- RF03. Cadastro de categorias de materiais.
- RF04. Listagem de categorias de materiais.
- RF05. Edicao de categorias de materiais.
- RF06. Exclusao de categorias quando possivel.
- RF07. Cadastro de materiais/produtos.
- RF08. Listagem de materiais/produtos.
- RF09. Edicao de materiais/produtos.
- RF10. Exclusao de materiais/produtos.
- RF11. Registro de entradas de estoque.
- RF12. Registro de saidas de estoque.
- RF13. Atualizacao automatica de quantidade em estoque.
- RF14. Listagem de movimentacoes.
- RF15. Cadastro de ativos patrimoniais.
- RF16. Listagem de ativos patrimoniais.
- RF17. Edicao de ativos patrimoniais.
- RF18. Exclusao de ativos patrimoniais.
- RF19. Dashboard interno apos login.
- RF20. Logout do usuario.
- RF21. Visualizacao de inventario de materiais.
- RF22. Visualizacao de numero patrimonial, descricao, localizacao e estado.
- RF23. Navegacao entre telas por menu/header.
- RF24. Mensagens de sucesso e erro nas operacoes principais.
- RF25. Base inicial com dados minimos para demonstracao.

## Requisitos nao funcionais atendidos

- RNF01. Uso de Spring Boot.
- RNF02. Estrutura Maven preservada.
- RNF03. Organizacao em camadas `controller`, `service`, `repository` e `model`.
- RNF04. Banco relacional com JPA/Hibernate.
- RNF05. Interface simples, intuitiva e responsiva.
- RNF06. Uso de Thymeleaf.
- RNF07. Visual inspirada em cores do SENAI-SP.
- RNF08. Codigo claro e didatico.
- RNF09. README com execucao, estrutura, RF e RNF.
- RNF10. Projeto preparado para iniciar sem erros e testar localmente.
- RNF11. Banco criado automaticamente pela aplicacao.
- RNF12. Formularios com validacoes basicas.
- RNF13. Organizacao visual consistente.
- RNF14. Projeto pronto para apresentacao academica.
- RNF15. Classes de dominio e telas com nomes em portugues.

## Estrutura do projeto

- `src/main/java/br/senai/estoque/gerenciamento_estoque/controller`: controllers MVC e autenticacao por sessao.
- `src/main/java/br/senai/estoque/gerenciamento_estoque/model`: entidades JPA e enum de movimentacao.
- `src/main/java/br/senai/estoque/gerenciamento_estoque/repository`: repositorios Spring Data JPA.
- `src/main/java/br/senai/estoque/gerenciamento_estoque/service`: regras de negocio.
- `src/main/resources/templates`: paginas Thymeleaf e fragments.
- `src/main/resources/static/css`: estilo base da interface.
- `src/main/resources/data.sql`: dados iniciais de autorizacao.

## Regras de negocio implementadas

- O login exige funcionario cadastrado, ativo e com senha correta.
- O cadastro so e permitido se nome e NIF existirem na tabela de funcionarios autorizados.
- A saida de estoque nao pode exceder o saldo atual do material.
- O saldo do material e atualizado automaticamente a cada movimentacao.
- Categoria nao pode ser excluida se estiver vinculada a materiais.
- Material nao pode ser excluido se possuir movimentacoes registradas.

## Observacoes

- A autenticacao foi feita com `HttpSession` para manter a solucao simples e didatica.
- Senhas foram mantidas em texto simples por ser um projeto academico introdutorio. Em producao, o ideal seria usar hash e Spring Security.
