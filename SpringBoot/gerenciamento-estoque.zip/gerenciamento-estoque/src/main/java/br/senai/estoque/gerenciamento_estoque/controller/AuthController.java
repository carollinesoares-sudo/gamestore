package br.senai.estoque.gerenciamento_estoque.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.senai.estoque.gerenciamento_estoque.model.Funcionario;
import br.senai.estoque.gerenciamento_estoque.service.AuthService;
import jakarta.servlet.http.HttpSession;

@Controller
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @GetMapping("/login")
    public String login(HttpSession session, Model model) {
        if (ControllerUtils.usuarioLogado(session)) {
            return "redirect:/app";
        }

        ControllerUtils.adicionarDadosSessao(model, session);
        return "auth/login";
    }

    @PostMapping("/login")
    public String fazerLogin(@RequestParam String nif,
            @RequestParam String senha,
            HttpSession session,
            RedirectAttributes redirectAttributes) {

        boolean loginOk = authService.login(nif, senha);
        if (!loginOk) {
            redirectAttributes.addFlashAttribute("erro", "NIF ou senha invalidos.");
            return "redirect:/login";
        }

        Funcionario funcionario = authService.buscarPorNif(nif.trim());
        session.setAttribute("usuarioLogado", true);
        session.setAttribute("nif", funcionario.getNif());
        session.setAttribute("nomeUsuario", funcionario.getNome());

        return "redirect:/app";
    }

    @GetMapping("/cadastro")
    public String cadastro(HttpSession session, Model model) {
        ControllerUtils.adicionarDadosSessao(model, session);
        return "auth/cadastro";
    }

    @PostMapping("/cadastro")
    public String fazerCadastro(@RequestParam String nome,
            @RequestParam String nif,
            @RequestParam String senha,
            RedirectAttributes redirectAttributes) {

        String resultado = authService.cadastrar(nome, nif, senha);
        if ("Cadastro realizado com sucesso.".equals(resultado)) {
            redirectAttributes.addFlashAttribute("sucesso", resultado + " Faça o login para entrar.");
            return "redirect:/login";
        }

        redirectAttributes.addFlashAttribute("erro", resultado);
        redirectAttributes.addFlashAttribute("nome", nome);
        redirectAttributes.addFlashAttribute("nif", nif);
        return "redirect:/cadastro";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session, RedirectAttributes redirectAttributes) {
        session.invalidate();
        redirectAttributes.addFlashAttribute("sucesso", "Logout realizado com sucesso.");
        return "redirect:/login";
    }
}
