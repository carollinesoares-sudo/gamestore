package br.senai.estoque.gerenciamento_estoque.service;

import java.util.List;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import br.senai.estoque.gerenciamento_estoque.model.CategoriaMaterial;
import br.senai.estoque.gerenciamento_estoque.repository.CategoriaMaterialRepository;

@Service
public class CategoriaMaterialService {

    private final CategoriaMaterialRepository categoriaMaterialRepository;

    public CategoriaMaterialService(CategoriaMaterialRepository categoriaMaterialRepository) {
        this.categoriaMaterialRepository = categoriaMaterialRepository;
    }

    public List<CategoriaMaterial> listarTodas() {
        return categoriaMaterialRepository.findAll()
                .stream()
                .sorted((a, b) -> a.getNome().compareToIgnoreCase(b.getNome()))
                .toList();
    }

    public CategoriaMaterial buscarPorId(Long id) {
        return categoriaMaterialRepository.findById(id)
                .orElseThrow(() -> new RegraNegocioException("Categoria não encontrada."));
    }

    public CategoriaMaterial salvar(CategoriaMaterial categoriaMaterial) {
        validarNomeUnico(categoriaMaterial);
        return categoriaMaterialRepository.save(categoriaMaterial);
    }

    public void excluir(Long id) {
        CategoriaMaterial categoria = buscarPorId(id);
        try {
            categoriaMaterialRepository.delete(categoria);
        } catch (DataIntegrityViolationException ex) {
            throw new RegraNegocioException("Nao foi possivel excluir a categoria porque ela esta vinculada a materiais.");
        }
    }

    private void validarNomeUnico(CategoriaMaterial categoriaMaterial) {
        String nome = categoriaMaterial.getNome().trim();
        categoriaMaterial.setNome(nome);

        boolean existe = categoriaMaterial.getId() == null
                ? categoriaMaterialRepository.existsByNomeIgnoreCase(nome)
                : categoriaMaterialRepository.existsByNomeIgnoreCaseAndIdNot(nome, categoriaMaterial.getId());

        if (existe) {
            throw new RegraNegocioException("Já existe uma categoria com esse nome.");
        }
    }
}
