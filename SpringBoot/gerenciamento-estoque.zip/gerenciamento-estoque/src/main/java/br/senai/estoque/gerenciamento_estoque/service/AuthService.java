package br.senai.estoque.gerenciamento_estoque.service;

import java.util.Optional;

import org.springframework.stereotype.Service;

import br.senai.estoque.gerenciamento_estoque.model.Funcionario;
import br.senai.estoque.gerenciamento_estoque.repository.FuncionarioAutenticadoRepository;
import br.senai.estoque.gerenciamento_estoque.repository.FuncionarioRepository;

@Service
public class AuthService {

    private final FuncionarioRepository funcionarioRepository;
    private final FuncionarioAutenticadoRepository funcionarioAutenticadoRepository;

    public AuthService(FuncionarioRepository funcionarioRepository,
            FuncionarioAutenticadoRepository funcionarioAutenticadoRepository) {
        this.funcionarioRepository = funcionarioRepository;
        this.funcionarioAutenticadoRepository = funcionarioAutenticadoRepository;
    }

    public String cadastrar(String nome, String nif, String senha) {
        nome = nome.trim();
        nif = nif.trim();
        senha = senha.trim();

        if (nome.isBlank() || nif.isBlank() || senha.isBlank()) {
            return "Preencha nome, NIF e senha.";
        }

        if (senha.length() < 4) {
            return "A senha deve ter pelo menos 4 caracteres.";
        }

        boolean autorizado = funcionarioAutenticadoRepository.existsByNifAndNomeAndAtivoTrue(nif, nome);
        if (!autorizado) {
            return "NIF e nome nao estao autorizados para cadastro.";
        }

        boolean jaExiste = funcionarioRepository.existsByNif(nif);
        if (jaExiste) {
            return "Ja existe um funcionario cadastrado com esse NIF.";
        }

        Funcionario funcionario = new Funcionario();
        funcionario.setNome(nome);
        funcionario.setNif(nif);
        funcionario.setSenha(senha);
        funcionario.setAtivo(true);
        funcionarioRepository.save(funcionario);

        return "Cadastro realizado com sucesso.";
    }

    public boolean login(String nif, String senha) {
        Optional<Funcionario> funcionarioOpt = funcionarioRepository.findByNif(nif.trim());
        if (funcionarioOpt.isEmpty()) {
            return false;
        }

        Funcionario funcionario = funcionarioOpt.get();
        if (!funcionario.isAtivo()) {
            return false;
        }

        return funcionario.getSenha().equals(senha);
    }

    public Funcionario buscarPorNif(String nif) {
        return funcionarioRepository.findByNifAndAtivoTrue(nif)
                .orElseThrow(() -> new RegraNegocioException("Funcionario nao encontrado na sessao."));
    }
}
