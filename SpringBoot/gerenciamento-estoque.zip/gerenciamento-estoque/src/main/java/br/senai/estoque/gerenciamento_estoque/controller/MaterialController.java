package br.senai.estoque.gerenciamento_estoque.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.senai.estoque.gerenciamento_estoque.model.Material;
import br.senai.estoque.gerenciamento_estoque.model.CategoriaMaterial;
import br.senai.estoque.gerenciamento_estoque.service.CategoriaMaterialService;
import br.senai.estoque.gerenciamento_estoque.service.MaterialService;
import br.senai.estoque.gerenciamento_estoque.service.RegraNegocioException;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

@Controller
@RequestMapping("/app/materiais")
public class MaterialController {

    private final MaterialService materialService;
    private final CategoriaMaterialService categoriaMaterialService;

    public MaterialController(MaterialService materialService, CategoriaMaterialService categoriaMaterialService) {
        this.materialService = materialService;
        this.categoriaMaterialService = categoriaMaterialService;
    }

    @GetMapping
    public String listar(Model model, HttpSession session) {
        String redirect = ControllerUtils.redirecionarSeNaoLogado(session);
        if (redirect != null) {
            return redirect;
        }

        ControllerUtils.adicionarDadosSessao(model, session);
        model.addAttribute("materiais", materialService.listarTodos());
        return "materiais/lista";
    }

    @GetMapping("/novo")
    public String novo(Model model, HttpSession session) {
        Material material = new Material();
        material.setAtivo(true);
        material.setQuantidade(0);
        material.setCategoria(new CategoriaMaterial());
        return abrirFormulario(material, model, session, "Novo material");
    }

    @GetMapping("/{id}/editar")
    public String editar(@PathVariable Long id, Model model, HttpSession session) {
        Material material = materialService.buscarPorId(id);
        return abrirFormulario(material, model, session, "Editar material");
    }

    @PostMapping("/salvar")
    public String salvar(@Valid @ModelAttribute("material") Material material,
            BindingResult bindingResult,
            Model model,
            HttpSession session,
            RedirectAttributes redirectAttributes) {

        String redirect = ControllerUtils.redirecionarSeNaoLogado(session);
        if (redirect != null) {
            return redirect;
        }

        if (bindingResult.hasErrors()) {
            return abrirFormulario(material, model, session,
                    material.getId() == null ? "Novo material" : "Editar material");
        }

        try {
            materialService.salvar(material);
            redirectAttributes.addFlashAttribute("sucesso", "Material salvo com sucesso.");
            return "redirect:/app/materiais";
        } catch (RegraNegocioException ex) {
            model.addAttribute("erro", ex.getMessage());
            return abrirFormulario(material, model, session,
                    material.getId() == null ? "Novo material" : "Editar material");
        }
    }

    @PostMapping("/{id}/excluir")
    public String excluir(@PathVariable Long id, RedirectAttributes redirectAttributes, HttpSession session) {
        String redirect = ControllerUtils.redirecionarSeNaoLogado(session);
        if (redirect != null) {
            return redirect;
        }

        try {
            materialService.excluir(id);
            redirectAttributes.addFlashAttribute("sucesso", "Material excluido com sucesso.");
        } catch (RegraNegocioException ex) {
            redirectAttributes.addFlashAttribute("erro", ex.getMessage());
        }
        return "redirect:/app/materiais";
    }

    private String abrirFormulario(Material material, Model model, HttpSession session, String titulo) {
        String redirect = ControllerUtils.redirecionarSeNaoLogado(session);
        if (redirect != null) {
            return redirect;
        }

        if (material.getCategoria() == null) {
            material.setCategoria(new CategoriaMaterial());
        }
        ControllerUtils.adicionarDadosSessao(model, session);
        model.addAttribute("material", material);
        model.addAttribute("categorias", categoriaMaterialService.listarTodas());
        model.addAttribute("tituloPagina", titulo);
        return "materiais/formulario";
    }
}
